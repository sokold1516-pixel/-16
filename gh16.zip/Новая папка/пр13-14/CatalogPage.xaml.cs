﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

namespace пр13_14.Pages
{
    public partial class CatalogPage : Page
    {
        private const string ConnectionString =
            @"Server=WIN-FQ3SEPJHQEH; Database=пр13; Integrated Security=true; TrustServerCertificate=True;";

        public CatalogPage()
        {
            InitializeComponent();
            LoadExhibits();
        }

        private void LoadExhibits()
        {
            var exhibits = new List<ExhibitCard>();

            try
            {
                using (var conn = new SqlConnection(ConnectionString))
                {
                    conn.Open();
                    string query = @"SELECT e.ExhibitsID, e.Title, e.Description, e.Condition, e.ImageData,
                                            h.Name as HallName, exp.Title as ExpositionTitle
                                    FROM Exhibitss e
                                    LEFT JOIN HallsStorages h ON e.HallsStoragesID = h.HallsStoragesID
                                    LEFT JOIN Expositions exp ON e.ExpositionsID = exp.ExpositionsID
                                    ORDER BY e.DateAdded DESC";

                    using (var cmd = new SqlCommand(query, conn))
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            BitmapImage imageSource = null;
                            bool hasImage = false;

                            if (!reader.IsDBNull(reader.GetOrdinal("ImageData")))
                            {
                                byte[] imageData = (byte[])reader["ImageData"];
                                if (imageData.Length > 0)
                                {
                                    imageSource = new BitmapImage();
                                    imageSource.BeginInit();
                                    imageSource.CacheOption = BitmapCacheOption.OnLoad;
                                    imageSource.StreamSource = new MemoryStream(imageData);
                                    imageSource.EndInit();
                                    imageSource.Freeze();
                                    hasImage = true;
                                }
                            }

                            exhibits.Add(new ExhibitCard
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("ExhibitsID")),
                                Title = reader.GetString(reader.GetOrdinal("Title")),
                                Description = reader.IsDBNull(reader.GetOrdinal("Description"))
                                    ? "Описание отсутствует"
                                    : reader.GetString(reader.GetOrdinal("Description")),
                                Condition = reader.IsDBNull(reader.GetOrdinal("Condition"))
                                    ? "Неизвестно"
                                    : reader.GetString(reader.GetOrdinal("Condition")),
                                HallName = reader.IsDBNull(reader.GetOrdinal("HallName"))
                                    ? "Не размещен"
                                    : reader.GetString(reader.GetOrdinal("HallName")),
                                ExpositionTitle = reader.IsDBNull(reader.GetOrdinal("ExpositionTitle"))
                                    ? "Нет экспозиции"
                                    : reader.GetString(reader.GetOrdinal("ExpositionTitle")),
                                ImageSource = imageSource,
                                HasImage = hasImage
                            });
                        }
                    }
                }

                lvExhibits.ItemsSource = exhibits;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}",
                    "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    public class ExhibitCard
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Condition { get; set; }
        public string HallName { get; set; }
        public string ExpositionTitle { get; set; }
        public BitmapImage ImageSource { get; set; }
        public bool HasImage { get; set; }

        public string ConditionColor
        {
            get
            {
                string cond = Condition?.ToLower() ?? "";
                if (cond == "excellent" || cond == "отличное")
                    return "#FF00C853";
                else if (cond == "good" || cond == "хорошее")
                    return "#FF00BCD4";
                else if (cond == "satisfactory" || cond == "удовлетворительное")
                    return "#FFFFC107";
                else if (cond == "poor" || cond == "плохое")
                    return "#FFFF5252";
                else
                    return "#FF90A4AE";
            }
        }

        public string ConditionIcon
        {
            get
            {
                string cond = Condition?.ToLower() ?? "";
                if (cond == "excellent" || cond == "отличное")
                    return "✓";
                else if (cond == "good" || cond == "хорошее")
                    return "✓";
                else if (cond == "satisfactory" || cond == "удовлетворительное")
                    return "!";
                else if (cond == "poor" || cond == "плохое")
                    return "✕";
                else
                    return "?";
            }
        }
    }
}