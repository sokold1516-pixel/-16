﻿using System.Windows.Media.Imaging;

namespace пр13_14
{
    public class ExhibitCard
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Condition { get; set; }
        public BitmapImage ImageSource { get; set; }
    }
}